package com.example.bufaloserver.seguridad;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * ★ NUEVO — hasheo del PIN de acceso (Usuario.pinHash/pinSalt), reemplaza el
 * texto plano que se guardaba antes en Usuario.pin.
 *
 * Por qué importa: antes cualquiera con acceso al archivo de la base (un
 * backup, un dispositivo físico robado, un rooteo) veía el PIN de los 4
 * usuarios/empleados en texto plano, sin ningún esfuerzo. El login en sí no
 * quedaba más expuesto por eso — ServidorHttp.manejarLogin exige además un
 * deviceToken de un dispositivo YA EMPAREJADO como ese usuario en particular,
 * así que un PIN filtrado sin el dispositivo emparejado no alcanza para
 * entrar — pero la base de datos en reposo sí quedaba expuesta.
 *
 * PBKDF2WithHmacSHA256 en vez de SHA-256/MD5 directo porque PBKDF2 está
 * pensado para ser LENTO a propósito (con muchas iteraciones), lo que
 * encarece un ataque de fuerza bruta offline contra la base robada. Dicho
 * eso: con un PIN de 4 dígitos numéricos el espacio de búsqueda es apenas
 * 10.000 valores — ni el mejor hash del mundo lo vuelve "seguro" contra
 * alguien que se toma el trabajo de probar los 10.000 offline. La ganancia
 * real de esto es tapar la exposición más barata y tonta (leer el archivo
 * y ver el PIN a simple vista), no convertir un PIN de 4 dígitos en una
 * contraseña fuerte — eso requeriría cambiar el esquema de autenticación
 * en sí (PINs más largos, límite de intentos, etc.), que queda fuera de
 * este fix.
 *
 * PBKDF2WithHmacSHA256 está disponible desde API 26 — coincide justo con
 * el minSdk de este proyecto (ver build.gradle.kts, comentario sobre la
 * Huawei AGS-L03), así que no hace falta ninguna librería externa ni un
 * fallback para SDKs viejos.
 */
public final class PinHasher {

    private static final String ALGORITMO = "PBKDF2WithHmacSHA256";

    // 120.000 iteraciones: un valor típico recomendado para PBKDF2-SHA256 en
    // 2024-2026. En el hardware más flojo que corre esta app (la Huawei
    // AGS-L03, Android 8), un login tarda un extra de algunas decenas de
    // milisegundos por esto — imperceptible para el usuario (el login ya
    // implica ida y vuelta de red), y sigue siendo rápido porque esto corre
    // UNA vez por login, no en un loop.
    private static final int ITERACIONES = 120_000;
    private static final int LONGITUD_CLAVE_BITS = 256;
    private static final int LONGITUD_SALT_BYTES = 16;

    private PinHasher() {}

    /** Genera una sal nueva, aleatoria, para UN usuario. Nunca se reutiliza entre usuarios. */
    public static String generarSalt() {
        byte[] salt = new byte[LONGITUD_SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /** Hashea un PIN contra una sal ya existente. Determinístico: mismo PIN + misma sal = mismo hash. */
    public static String hashear(String pin, String saltBase64) {
        try {
            byte[] salt = Base64.getDecoder().decode(saltBase64);
            PBEKeySpec spec = new PBEKeySpec(
                    (pin != null ? pin : "").toCharArray(), salt, ITERACIONES, LONGITUD_CLAVE_BITS);
            SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGORITMO);
            byte[] hash = skf.generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            // No debería pasar nunca en un dispositivo API 26+ real — si
            // pasa, es un problema del entorno (JCE mal configurado), no
            // algo de lo que el llamador se pueda recuperar con sentido.
            throw new RuntimeException("No se pudo hashear el PIN (" + ALGORITMO + " no disponible)", e);
        }
    }

    /**
     * Compara un PIN candidato (lo que tipeó el usuario al loguearse) contra
     * el hash+sal guardados. Comparación en tiempo constante sobre el
     * resultado final — no evita que alguien mida CUÁNTO TARDA en calcular
     * el hash (eso depende solo de ITERACIONES, siempre igual), pero sí
     * evita la fuga más básica de comparar el string resultante char por
     * char con early-exit (String.equals).
     */
    public static boolean verificar(String pinCandidato, String saltBase64, String hashEsperadoBase64) {
        if (saltBase64 == null || hashEsperadoBase64 == null) return false;
        String hashCandidato = hashear(pinCandidato, saltBase64);
        return constantTimeEquals(hashCandidato, hashEsperadoBase64);
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int diferencia = 0;
        for (int i = 0; i < a.length(); i++) {
            diferencia |= a.charAt(i) ^ b.charAt(i);
        }
        return diferencia == 0;
    }
}
